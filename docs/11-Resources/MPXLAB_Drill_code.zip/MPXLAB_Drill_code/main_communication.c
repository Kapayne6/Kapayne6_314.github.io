#include "mcc_generated_files/system/system.h"

#define PREFIX1 'A'
#define PREFIX2 'Z'
#define SUFFIX1 'Y'
#define SUFFIX2 'B'

#define MY_ID    'K'        // your subsystem ID.
#define TEAM_IDS "CVKT"      // known teammates (self-messages allowed separately)

#define MAX_MSG_LEN 58

volatile uint8_t rx_state = 0;
volatile uint8_t rx_len = 0;
volatile uint8_t rx_buffer[MAX_MSG_LEN];

volatile char sender_id = 0;
volatile char receiver_id = 0;

volatile uint8_t send_flag = 0;


// =========================
// CHECK IF SENDER IS VALID
// =========================
uint8_t is_known(char id)
{
    uint8_t i = 0;
    while(TEAM_IDS[i] != '\0')
    {
        if(TEAM_IDS[i] == id) return 1;
        i++;
    }
    return 0;
}

// =========================
// TIMER ISR (RATE LIMIT)
// =========================
void TMR0_ISR(void)
{
    send_flag = 1;
}

// =========================
// SEND A FULL MESSAGE FRAME
// =========================
void Send_Frame(char sender, char receiver, uint8_t *data, uint8_t len)
{
    uint8_t i = 0;
    if(len > MAX_MSG_LEN) len = MAX_MSG_LEN;

    UART1_Write(PREFIX1);
    UART1_Write(PREFIX2);
    UART1_Write(sender);
    UART1_Write(receiver);

    while(i < len)
    {
        if(data[i] != PREFIX1 && data[i] != PREFIX2 &&
           data[i] != SUFFIX1 && data[i] != SUFFIX2)
        {
           // UART1_Write(data[i]);
        }
        i++;
    }

    UART1_Write(SUFFIX1);
    UART1_Write(SUFFIX2);
}

// =========================
// FORWARD MESSAGE (RED LED)
// =========================
void Forward_Message(char sender, char receiver, uint8_t *data, uint8_t len)
{
    IO_RD4_SetHigh();   // RED LED ON
    IO_RC7_SetLow();    // BLUE LED OFF

    Send_Frame(sender, receiver, data, len);

    __delay_ms(80);
    IO_RD4_SetLow();
}

// =========================
// MESSAGE FOR ME (BLUE LED)
// =========================
void Process_My_Message(uint8_t *data, uint8_t len)
{
    IO_RC7_SetHigh();   // BLUE LED ON
    IO_RD4_SetLow();    // RED LED OFF

    __delay_ms(300);
    IO_RC7_SetLow();
}

// =========================
// HANDLE COMPLETE MESSAGE
// =========================
void Handle_Message(char sender, char receiver, uint8_t *data, uint8_t len)
{
    // ERROR HANDLED: unknown sender (but allow self-messages)
    if(sender != MY_ID && !is_known(sender))
    {
        return;   // ignore unknown sender
    }

    // Forward if not for me
    if(receiver != MY_ID)
    {
        Forward_Message(sender, receiver, data, len);
        return;
    }

    // Message is for me
    Process_My_Message(data, len);
}

// =========================
// UART RECEIVE ISR
// =========================
void My_UART1_ReceiveISR(void)
{
    uint8_t c = UART1_Read();

    // Debug: prove ISR is firing
    IO_RD4_Toggle();

    if(rx_state == 0)
    {
        if(c == PREFIX1) rx_state = 1;
    }
    else if(rx_state == 1)
    {
        if(c == PREFIX2) rx_state = 2;
        else rx_state = 0;
    }
    else if(rx_state == 2)
    {
        sender_id = c;
        rx_state = 3;
    }
    else if(rx_state == 3)
    {
        receiver_id = c;
        rx_len = 0;
        rx_state = 4;
    }
    else if(rx_state == 4)
    {
        if(c == SUFFIX1)
        {
            rx_state = 5;
        }
        else
        {
            if(rx_len < MAX_MSG_LEN)
                rx_buffer[rx_len++] = c;
            else
                rx_state = 0;
        }
    }
    else if(rx_state == 5)
    {
        if(c == SUFFIX2)
            Handle_Message(sender_id, receiver_id, rx_buffer, rx_len);

        rx_state = 0;
    }
}

// =========================
// SEND TEST MESSAGE TO SELF
// =========================
/*
void Send_Test_To_Myself(void)
{
    uint8_t msg = {"AZU793839YB"};
    Send_Frame(msg);
}
*/
// =========================
// MAIN LOOP
// =========================
void main(void)
{
    SYSTEM_Initialize();
        // Attach your ISR to the UART driver
    // Attach your custom ISR
    UART1_ReceiveInterruptEnable();


    //IO_RC7_SetLow();   // BLUE LED OFF
    //IO_RD4_SetLow();   // RED LED OFF

    INTERRUPT_GlobalInterruptEnable();
   
    while(1)
    {
        //Handle_Message(sender_id, receiver_id, rx_buffer, rx_len);
        if(send_flag)
        {
            send_flag = 0;
           
            // Send a message to yourself for testing
            //Send_Test_To_Myself();
        }
    }
}
