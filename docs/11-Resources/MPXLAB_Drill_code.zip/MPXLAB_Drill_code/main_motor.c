#include "mcc_generated_files/system/system.h"
int main(void)
{
    SYSTEM_Initialize();
    UART1_Initialize();
    SPI1_Initialize();
    uint8_t FWD = 0b11101111;
    uint8_t REV = 0b11101101;
    SPI1_Host_Open(HOST_CONFIG);
    CS_SetHigh();
    __delay_ms(1000);
    
    PWM_SetLow();
    DIR_SetLow();
    DIS_SetLow();

    while(1)
    {
        CS_SetLow();
        __delay_us(1);
        SPI1_ByteExchange(FWD);
        __delay_ms(1);
        CS_SetHigh();
        __delay_ms(1000);
        CS_SetLow();
        __delay_us(1);
        SPI1_ByteExchange(REV);
        __delay_ms(3);
        CS_SetHigh();
        __delay_ms(1000);
    }    
}
/*
 * fwd = dis:0, pwm:1, dir:1, out1: high, out2: low
 * rev = dis:0, pwm:1, dir:0, out1: low, out2: high
 */